
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

app.post('/withdraw', (req, res) => {
    console.log("Withdraw request:", req.body);
    res.json({ ok: true });
});

app.get('/', (req, res) => res.send('QadamCoin Bot Server Working'));

app.listen(3000, () => console.log("Server running on port 3000"));
